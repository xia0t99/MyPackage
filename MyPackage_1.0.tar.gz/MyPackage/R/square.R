
square <-
function(x) {return (x^2)}
