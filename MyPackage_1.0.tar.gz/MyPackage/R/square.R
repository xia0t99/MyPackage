
square <-
function(x) {return (x^2)}

cube <- function(y) {return(y^3)}
